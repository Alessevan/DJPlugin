# NoteBlockAPI
[![](https://jitpack.io/v/koca2000/NoteBlockAPI.svg)](https://jitpack.io/#koca2000/NoteBlockAPI) [![Build Status](http://ci.haprosgames.com/buildStatus/icon?job=NoteBlockAPI)](http://ci.haprosgames.com/job/NoteBlockAPI)

For information about this Spigot/Bukkit API, go to https://www.spigotmc.org/resources/noteblockapi.19287/

Dev builds are available at [Jenkins](http://ci.haprosgames.com/job/NoteBlockAPI/ "Jenkins")
