package com.xxmicloxx.NoteBlockAPI;

/**
 * @deprecated {@link com.xxmicloxx.NoteBlockAPI.model.FadeType}
 */
@Deprecated
public enum FadeType {

	FADE_LINEAR

}
