package com.xxmicloxx.NoteBlockAPI.model;

public enum FadeType {

	NONE,
	LINEAR

}
