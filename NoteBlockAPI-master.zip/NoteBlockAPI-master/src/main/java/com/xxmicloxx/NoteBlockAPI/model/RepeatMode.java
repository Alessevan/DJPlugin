package com.xxmicloxx.NoteBlockAPI.model;

public enum RepeatMode {
    NO,ONE,ALL;
}
