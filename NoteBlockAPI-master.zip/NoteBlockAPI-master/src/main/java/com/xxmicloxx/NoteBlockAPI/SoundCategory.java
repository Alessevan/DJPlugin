package com.xxmicloxx.NoteBlockAPI;

/**
 * @deprecated {@link com.xxmicloxx.NoteBlockAPI.model.SoundCategory}
 */
@Deprecated
public enum SoundCategory {

	MASTER,
	MUSIC,
	RECORDS,
	WEATHER,
	BLOCKS,
	HOSTILE,
	NEUTRAL,
	PLAYERS,
	AMBIENT,
	VOICE;

}
